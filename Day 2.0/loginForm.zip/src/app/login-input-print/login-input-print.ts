import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login-input-print',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login-input-print.html',
  styleUrls: ['./login-input-print.css']
})
export class LoginInputPrintComponent {
  user = {
    email: '',
    password: ''
  };

  onSubmit() {
    console.log('Email:', this.user.email);
    console.log('Password:', this.user.password);
  }
}
